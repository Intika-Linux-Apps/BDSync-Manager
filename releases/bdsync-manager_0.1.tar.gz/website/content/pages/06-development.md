Title: Development

## Get the sources ##

*bdsync-manager* is kindly hosted by [savannah.nongnu.org](https://savannah.nongnu.org/projects/bdsync-manager/).

Code repository:

    https://savannah.nongnu.org/git/?group=bdsync-manager


## Mailinglist ##

Ask questions, discuss use cases, receive release announcements and help other fellow users on the [mailinglist](https://savannah.nongnu.org/mail/?group=bdsync-manager).


## Report problems ##

Report problems in the [support tracker at savannah.nongnu.org](https://savannah.nongnu.org/support/?group=bdsync-manager).

Alternatively you may want to ask questions on the [mailinglist](https://savannah.nongnu.org/mail/?group=bdsync-manager).
