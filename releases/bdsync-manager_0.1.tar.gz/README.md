# bdsync-manager #


*bdsync-manager* maintains and executes your synchronization tasks of local or remote blockdevices with [bdsync](https://github.com/TargetHolding/bdsync). It simplifies the setup of regular synchronization operations.

*bdsync-manager* is written in [Python](http://python.org) and licensed under the [GPL v3 or later](http://www.gnu.org/licenses/gpl.txt).

See the [website](http://www.nongnu.org/bdsync-manager/) for more details.
